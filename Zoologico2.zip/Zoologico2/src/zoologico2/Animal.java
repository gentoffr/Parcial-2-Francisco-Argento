/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package zoologico2;

import java.util.Objects;
import java.io.Serializable;
public class Animal implements CSVSerializable, Comparable<Animal>, Serializable{
    private int id;
    private String nombre;
    private String especie;
    private TipoAlimentacion alimentacion;

    public Animal(int id, String nombre, String especie, TipoAlimentacion alimentacion) {
        this.id = id;
        this.nombre = nombre;
        this.especie = especie;
        this.alimentacion = alimentacion;
    }
    
    @Override
    public String toCSV()
    {
        return id +","+ nombre + "," + especie + "," + alimentacion.name();
    }
    public static Animal fromCSV(String csv)
    {
        String[] partes = csv.split(","); // divido por comas la linea del csv, luego se usa en un for en al llamarlo
        int id = Integer.parseInt(partes[0]); //guardo los atributos en variables para crear el animal
        String nombre = partes[1];
        String especie = partes[2];
        TipoAlimentacion alimentacion = TipoAlimentacion.valueOf(partes[3].toUpperCase());
        return new Animal(id, nombre, especie, alimentacion); // creo el animal a partir de los datos obtenidos de una linea CSV
    }
    @Override
    public int compareTo(Animal a) {
        return Integer.compare(this.id, a.id); // uso el metodo de la clase integer para comparar enteros
    }
    @Override
    public int hashCode()
    {
        return Objects.hash(id);
    }
    @Override
    public boolean equals(Object o)
    {
         // Este override de equals me permite compara los parametros que yo deseo para saber si es efectivamente igual el objeto ingresado parametricamente
        if (this == o)
        {
            return true;
        }
        if(o == null || o.getClass() != getClass()) // Si es null o no de esta clase 
        {
            return false;
        }
        Animal p = (Animal) o; // Casteo del objeto ingresado por parametro, para poder acceder a sus atributos
        return p.id == id; // Si tanto ID como nombre coinciden, devolver true
    }

    @Override
    public String toString() {
        return "Animal{" + "id=" + id + ", nombre=" + nombre + ", especie=" + especie + ", alimentacion=" + alimentacion + '}';
    }

    public TipoAlimentacion getAlimentacion() {
        return alimentacion;
    }

    public String getNombre() {
        return nombre;
    }
    
}
