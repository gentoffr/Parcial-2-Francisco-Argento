/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package zoologico2;

import java.io.*;
import java.util.*;

public class test {

    public static void main(String[] args) {
        try {
// Crear un zoológico de animales
            Zoologico<Animal> zoologico = new Zoologico<>();
            zoologico.agregar(new Animal(1, "Leon", "Panthera leo",
                    TipoAlimentacion.CARNIVORO));
            zoologico.agregar(new Animal(2, "Elefante", "Loxodonta",
                    TipoAlimentacion.HERBIVORO));
            zoologico.agregar(new Animal(3, "Oso", "Ursus arctos",
                    TipoAlimentacion.OMNIVORO));
            zoologico.agregar(new Animal(4, "Zorro", "Vulpes vulpes",
                    TipoAlimentacion.CARNIVORO));
            zoologico.agregar(new Animal(5, "Gorila", "Gorilla gorilla",
                    TipoAlimentacion.OMNIVORO));
// Mostrar todos los animales en el zoológico
            System.out.println("Inventario de animales:");
            zoologico.paraCadaElemento(animal -> System.out.println(animal));
            System.out.println("-------------------------");
// Filtrar animales por tipo de alimentación CARNIVORO
            System.out.println("\nAnimales CARNIVOROS:");
            List<Animal> carnivoros = zoologico.filtrar(p -> p.getAlimentacion().equals(TipoAlimentacion.CARNIVORO)); // si "p" coincide con alimentacion carnivora, se agrega a la lista
            carnivoros.forEach(System.out::println);
            System.out.println("-------------------------");

// Filtrar animales cuyo nombre contiene "León"
            System.out.println("\nAnimales cuyo nombre contiene 'Leon':");
            List<Animal> leones = zoologico.filtrar(p -> p.getNombre().equals("Leon"));
            leones.forEach(System.out::println);
            // Ordenar animales de manera natural (por id)
            System.out.println("-------------------------");
            System.out.println("\nAnimales ordenados de manera natural (por id):");
            zoologico.ordenar();
            zoologico.paraCadaElemento(animal -> System.out.println(animal));
            System.out.println("-------------------------");
            // Ordenar animales por nombre utilizando un Comparator
            System.out.println("\nAnimales ordenados por nombre:");
            zoologico.ordenar((a1, a2) -> a1.getNombre().compareTo(a2.getNombre())); // dios se apiade de mi alma si tengo que explicar como funciona esto
            //pero basicamente agarro dos animales de la lista y los comparo, (el primero con todos, el segundo co
            zoologico.paraCadaElemento(animal -> System.out.println(animal));
            System.out.println("********************");
            // Guardar el zoológico en un archivo binario
            zoologico.guardarEnArchivo("src/zoologico2/animales.dat");
            List<Animal> desdeBinario = zoologico.cargarDesdeArchivo("src/zoologico2/animales.dat");
            // la consigna pide guardar el inventario y mi metodo guarda una lista
            // si quisiera cargar sobre una variable nueva de tipo zoologico, mi metodo deberia hacer un addall a su lista de animales
            // lo haria pero no llego a terminar el parcial
            desdeBinario.forEach(System.out::println);
            System.out.println("::::::::::::::::::::::::");
            // Guardar el zoológico en un archivo CSV
            zoologico.guardarEnCSV("src/zoologico2/animales.csv");
            List<Animal> desdeCSV = zoologico.cargarDesdeCSV("src/zoologico2/animales.csv");
            desdeCSV.forEach(System.out::println);
        } catch (Exception e) {
            System.err.println("Error: " + e.getMessage());
        }
    }
}
