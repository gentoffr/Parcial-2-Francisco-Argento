/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package zoologico2;

import java.util.*;
import java.util.Collections;
import java.util.function.*;
import java.io.*;

public class Zoologico<T extends CSVSerializable & Comparable> {

    private List<T> animales = new ArrayList<>();

    // voy a usar <T> todo el tiempo porque es generico
    public void agregar(T animal)// si no esta lo agrego
    {
        if (animal != null && !estaEnLista(animal)) {
            animales.add(animal);
        }
        else
        {
            System.out.println("El animal " + animal + " ya se encuentra en la lista");
        }
    }

    private boolean estaEnLista(T animal) // chequeo si esta en la lista
    {
        int i = 0; 
        while (i < animales.size()) 
        {
            if (animales.get(i).equals(animal)) 
            {
                return true;
            }
            i++; 
        }
        return false; 
    }

    public T obtenerPorIndice(int indice) {
        return animales.get(indice);
    }

    public T eliminarPorIndice(int indice) {
        return animales.remove(indice);
    }

    public List<T> filtrar(Predicate<T> criterio) //toma un objeto que implementa predicate, que viene en forma de lambda
    {
        List<T> auxRetorno = new ArrayList<>(); //aux de retorno
        //lambda para aplicar una accion por cada animal, podria haber usado paraCadaElemento pero lo implemente mas tarde
        animales.forEach(a -> {
            if (criterio.test(a)) {
                auxRetorno.add(a); //add al retorno si pasa el criterio lambda
            }
        });
        return auxRetorno;
    }

    public void ordenar() {
        Collections.sort(animales);
    }

    public void ordenar(Comparator<T> comparator) {
        animales.sort(comparator);
    }

    public void guardarEnArchivo(String archivo) {
        try (ObjectOutputStream salida = new ObjectOutputStream(new FileOutputStream(archivo))) //lector de objetos serializados a partir del lector basico
        {
            salida.writeObject(animales); // guardo la lista
            System.out.println("Animales guardados con éxito.");
        } catch (IOException e) {
            System.out.println(e);
        }
    }

    public List<T> cargarDesdeArchivo(String nombreArchivo) {
        List<T> aux = new ArrayList<>(); // lista auxiliar de retorno
        try (ObjectInputStream in = new ObjectInputStream(new FileInputStream(nombreArchivo))) //lector de objetos serializados a partir del lector basico
        //ademas me ahorra .close()
        {
            aux = (List<T>) in.readObject(); // de serializa el objeto guardado y lo castea a lista
            System.out.println("Animales cargados con éxito.");
        } catch (IOException | ClassNotFoundException e) {
            System.out.println(e);
        }
        return aux;
    }

    public void paraCadaElemento(Consumer<T> accion) {
        animales.forEach(accion);
    }

    public void guardarEnCSV(String archivo) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(archivo))) //creacion del escritor buffered a partir del escritor basico
        //ademas me ahorra .close()

        {
            for (T animal : animales) {
                writer.write(animal.toCSV()); // escribe el elemento en el csv
                writer.newLine(); // salto de linea entre cada elemento
            }
            System.out.println("Los animales han sido guardados en el archivo CSV.");
        } catch (IOException e) {
            System.out.println("Ocurrió un error al guardar los animales en el archivo CSV.");
        }
    }

    public List<T> cargarDesdeCSV(String archivo) {
        List<T> aux = new ArrayList<>(); // lista auxiliar a retornar
        try (BufferedReader reader = new BufferedReader(new FileReader(archivo))) // crear el lector buffered a partir del basico
            //ademas me ahorra .close()
        {
            String linea;
            while ((linea = reader.readLine()) != null) //no me acuerdo como se llama lo de hacer linea = reader.readline()
            {
                if (linea.trim().isEmpty()) {
                    continue; // si la linea esta vacia es ignorada
                }
                // convertir la línea CSV en un objeto Animal
                T animal = (T) Animal.fromCSV(linea); 
                // el metodo es estatico de Animal, ocurre por cada iteracion
                // obtiene cada linea del reader.readline en la clausula del while
                aux.add(animal); // agregar a la lista
            }
            System.out.println("Los animales han sido cargados desde el archivo CSV.");
        } catch (IOException e) {
            System.out.println("Ocurrió un error al cargar los animales desde el archivo CSV.");
        }
        return aux;
    }
}

